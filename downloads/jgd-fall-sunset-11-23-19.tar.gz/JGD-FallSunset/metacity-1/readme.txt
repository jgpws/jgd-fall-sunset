JGD-FallSunset

The code for the Metacity theme in the file metacity-theme-2.xml is a derivative work of the code from the Numix project, licensed under the GPLv3. The code in the file is also licensed under the terms of the General Public Licence, version 3.

Numix project: https://github.com/numixproject
Metacity theme: https://github.com/numixproject/numix-gtk-theme/tree/master/src/metacity-1

Copyright 2013 Satyajit Sahoo